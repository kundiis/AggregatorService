package ws.mtom.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Calendar;
import java.util.Properties;
import java.util.Random;

public class Populate extends BlogClient {
	// random names to use when populating the ws
	public static final String[] authors = { "Ethan", "Aden", "Liam", "Jack",
			"Andrew", "Oliver", "Samuel", "Evan", "Isabella", "Emma", "Ella",
			"Claire", "Emilee", "Grace", "Avery", "Sarah", "Cadence" };

	public static final String[] tags = { "fashion", "health", "news" };
	final String[] Blogs = { "fashion.txt", "blog.txt","Health.txt","news.txt","book.txt"};
			
	double d;
	Properties prop;

	
	public Populate() {

		prop = new Properties();
		//System.out.println("after creating properties");

		final InputStream in1 = Thread.currentThread().getContextClassLoader()
				.getResourceAsStream("test.properties");
		if (in1 == null) {
			//System.out.println("therad properties also null");
		}

		if (in1 != null) {
			System.out.println("properties file loaded");
			try {
				prop.load(in1);
			} catch (final IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}


	/**
	 * fill the ws with data
	 * 
	 * @param times
	 *            minimum of two
	 */
	public void populateWS(int times) throws Exception {
		// miminum of two times
		if (times < 2) {
			times = 2;
		}

		System.out.println("\nPopulate: adding " + times + " Blogs");
		final Random rand = new Random(System.currentTimeMillis());
		long atime = 0;
		long asize = 0;
		long afirst = 0;
		for (int n = 0; n < times; n++) {
		    final String author = authors[rand.nextInt(authors.length)];
			setAuthor(author);
			final Calendar cal = Calendar.getInstance();
			setTime(cal.toString());
			final String tag = tags[rand.nextInt(tags.length)];
			setTag(tag);
			d = Math.random() * 90;
			setLatitude(String.valueOf(d));
			d = Math.random() * 180;
			setLongitude(String.valueOf(d));
			setType("Blog");
            String blogname = null;
            blogname = Blogs[rand.nextInt(Blogs.length)];

			// creating Blog file
            System.out.println("Blog Name:"+blogname);
            System.out.println("Author:"+author);
            System.out.println("Tag:"+tag);
			final File f = createTempBlog(prop.getProperty("inputPath")+blogname);
			//System.out.println("File created of size:" + f.length());
			// Blogfile end

			// for stats we don't want to include the time create the file
			asize += f.length();
			final long st = System.currentTimeMillis();

			add(f);

			atime += System.currentTimeMillis() - st;
			if (n == 0) {
				afirst = atime;
			}

		}

		System.out
				.println("\n----------------------------------------------------------------");
		System.out
				.println("Upload Stats (excluding temporary Blog creation):\n");
		System.out.println("Transferred:                 " + times + " Blogs");
		System.out.println("Total time:                  " + (atime / 1000)
				+ " sec");
		System.out.println("Amount transferred:          " + (asize / 1024)
				+ " kbytes");
		System.out.println("Average transfer rate:       "
				+ ((asize / 1024) / (atime / 1000)) + " kb/sec");
		System.out.println("Average time per file:       " + (atime / times)
				+ " msec");
		System.out.println("First transfer:              " + afirst + " msec");
		System.out.println("Subsequent transfers:        "
				+ ((atime - afirst) / (times - 1)) + " msec/file");
		System.out
				.println("----------------------------------------------------------------");
	}

	/**
	 * create a temporary file to transfer
	 * 
	 * @return
	 */
	public static File createTempBlog(final String fileName) {
		// create Blog
		// Read from a file
		final File file = new File(fileName);
		final File filewtr = new File(fileName);
		byte[] retbytes = null;
		retbytes = new byte[(int) file.length()];
		//System.out.println("Blog File length:" + (int) file.length());
		//System.out.println("No:0f bytes:" + retbytes.length);

		if (!filewtr.exists()) {
			FileOutputStream os = null;
			FileInputStream fis = null;

			// logic
			// Read in the bytes
			int offset = 0;
			int numRead = 0;
			try {
				fis = new FileInputStream(file);
				os = new FileOutputStream(filewtr);
				while ((offset < retbytes.length)
						&& ((numRead = fis.read(retbytes, offset,
								retbytes.length - offset)) >= 0)) {

					offset += numRead;
				}

				// Ensure all the bytes have been read in
				if (offset < retbytes.length) {
					throw new IOException("Could not completely read file "
							+ file.getName());
				}

				// logic end

				os.write(retbytes);
			} catch (final IOException e) {
				// TODO Auto-generated catch block
				System.out.println("Exception happened:");
				e.printStackTrace();
			}

			//System.out.println("Blog obj:" + fis.toString());
			System.out.println("---> created temporary Blogfile: "
					+ filewtr.getAbsolutePath() + ", "
					+ (filewtr.length() / 1024) + " kbytes");

		}
		return filewtr;

	}

	/**
	 * the demonstration
	 * 
	 * @param args
	 */
	public static void main(final String[] args) {
		try {
			final Populate p = new Populate();
			p.populateWS(5);

		} catch (final Exception e) {
			e.printStackTrace();
		}
	}
}
