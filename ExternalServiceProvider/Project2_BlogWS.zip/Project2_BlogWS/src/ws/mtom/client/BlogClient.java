package ws.mtom.client;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;

import org.apache.axis2.Constants;
import org.apache.axis2.client.Options;
//import org.example.www.mtomblogtransfer.DownloadAllMediaRequest;
//import org.example.www.mtomblogtransfer.DownloadAllMediaResponse;
import org.example.www.mtomblogtransfer.DownloadBlogRequest;
import org.example.www.mtomblogtransfer.DownloadBlogResponse;
//import org.example.www.mtomblogtransfer.DownloadSpecificMediaRequest;
//import org.example.www.mtomblogtransfer.DownloadSpecificMediaResponse;
import org.example.www.mtomblogtransfer.BlogData;
import org.example.www.mtomblogtransfer.BlogInfo;
import org.example.www.mtomblogtransfer.UploadBlog;
import org.example.www.mtomblogtransfer.UploadBlogResponse;

/**
 * Proxy/Simplify access to the web service's methods
 * 
 * @author gash1
 * 
 */
public abstract class BlogClient {
	//public static final String sEndPoint = "http://localhost:8080/axis2/services/MTOMBlogTransfer";
	// public static final String sEndPoint =
	// "http://localhost:8080/axis2/services/mtomblogtransfer";

	// Increase the time out when sending large attachments
	// public static final int sTimeout = 60000;

	private final String endPoint = null;
	private String author;
	private String time;
	private String tag;
	private String latitude;
	private String longitude;
	private String name;
	private String type;

	// client-side caching
	private File cacheDir;
	Properties prop;

	private ws.mtom.MTOMBlogTransferStub stub;

	/**
	 * use default URL (endpoint)
	 */
	public BlogClient() {
		//this(sEndPoint);
		prop = new Properties();
		System.out.println("after creating properties");

		final InputStream in1 = Thread.currentThread().getContextClassLoader()
				.getResourceAsStream("test.properties");
		if (in1 == null) {
			System.out.println("therad properties also null");
		}

		if (in1 != null) {
			System.out.println("properties in1 not null");
			try {
				prop.load(in1);
			} catch (final IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

	/**
	 * Specify URL (endpoint)
	 * 
	 * @param endPoint
	 */
//	public BlogClient(final String endPoint) {
//		this.endPoint = endPoint;
//	}

	/**
	 * @return the author
	 */
	public String getAuthor() {
		return author;
	}

	/**
	 * @param requestor
	 *            the author to set
	 */
	public void setAuthor(final String author) {
		this.author = author;
	}

	public String getTime() {
		return time;
	}

	public void setTime(final String time) {
		this.time = time;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(final String tag) {
		this.tag = tag;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(final String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(final String longitude) {
		this.longitude = longitude;
	}

	public String getName() {
		return name;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(final String type) {
		this.type = type;
	}

	protected synchronized ws.mtom.MTOMBlogTransferStub connect()
			throws Exception {
		if (stub == null) {
			stub = new ws.mtom.MTOMBlogTransferStub(prop.getProperty("serviceEndPoint"));

			// client will use MTOM otherwise SwA is used. If using SwA, more
			// memory will be required to create the messages.
			final Options options = stub._getServiceClient().getOptions();
			if (options != null) {
				options.setProperty(Constants.Configuration.ENABLE_MTOM,
						Constants.VALUE_TRUE);

				if (cacheDir != null) {
					System.out.println("---> cache enabled, using "
							+ cacheDir.getAbsolutePath());

					if (!cacheDir.exists()) {
						cacheDir.mkdir();
					}

					// Note: This will cache files onto the client's computer in
					// the specified directory. If there is a security issue
					// with the data transmitted, this may pose a risk
					options.setProperty(
							Constants.Configuration.CACHE_ATTACHMENTS,
							Constants.VALUE_TRUE);
					options.setProperty(
							Constants.Configuration.ATTACHMENT_TEMP_DIR,
							cacheDir.getAbsolutePath());
					options
							.setProperty(
									Constants.Configuration.FILE_SIZE_THRESHOLD,
									"4000");
				}

				System.out.println("---> MTOM is enabled");
			} else {
				System.out.println("---> MTOM is not enabled, using SwA");
			}
		}

		return stub;
	}

	public String add(final File f) throws Exception {
		final ws.mtom.MTOMBlogTransferStub svr = connect();

		final UploadBlog uf = new UploadBlog();
		uf.setAuthor(author);
		uf.setTime(time);
		uf.setLatitude(latitude);
		uf.setLongitude(longitude);
		uf.setType("Blog");
		uf.setTag(tag);
		uf.setBlogName(f.getName());

		// file to upload
		final DataSource ds = new FileDataSource(f);

		final DataHandler dh = new DataHandler(ds);
		uf.setData(dh);
		//System.out.println("---> MTOM is enabled");

		final UploadBlogResponse rtn = svr.uploadBlog(uf);
		System.out.println("Response back from server with BlogID:"
				+ rtn.getBlogId());
		if (rtn == null) {
			return null;
		} else {
			return rtn.getBlogId();
		}
	}
   //regular download Blog without the ring
	public File[] retrieveBlog(final String mediaType,final String searchType, final String value,
			 final File dir) throws Exception {

		//regular download
		if (dir == null ) {
			return null;
		}
		if (dir.exists()) {
			System.out.println("Dir exists");
			System.out.println("Dirpath:" + dir.getName());
		}

		if (!dir.exists() && !dir.mkdirs()) {
			throw new RuntimeException(
					"Failed to create directory to retrieve Blog to");
		}

		final ws.mtom.MTOMBlogTransferStub svr = connect();
		final DownloadBlogRequest df = new DownloadBlogRequest();
		df.setSearchType(searchType);
		df.setValue(value);
		System.out.println("Webservice request send for Blog with searchtype: "
				+ df.getSearchType() + "and value:" + value);
		//BlogInfo [] fileinfo = null;
		if(searchType.equals("Author")){
		  	

		}
		//System.out.println(" Requested Blog name:" + fi.getName());
		File[] f = null;
		final DownloadBlogResponse rtn = svr.downloadBlog(df);
		if (rtn != null && rtn.getData() != null) {
			System.out.println("Response recieved..");
			
			BlogData[] idata = rtn.getData();
			 f = new File[idata.length];
			FileOutputStream[] fos = new FileOutputStream[idata.length];
						
			for(int i =0 ;i <idata.length;i++){
			 try {

				f[i] = new File(dir, idata[i].getInfo().getName());
				
				fos[i] = new FileOutputStream(f[i]);
			
				idata[i].getData().writeTo(fos[i]);
			    fos[i].flush();
				} finally {
					if (fos[i] != null)
					 fos[i].close();
				}
				
				
			}		
			
		} else {
			System.out.println("** nothing to download! **");
		}

		return f;

		
	}



}
