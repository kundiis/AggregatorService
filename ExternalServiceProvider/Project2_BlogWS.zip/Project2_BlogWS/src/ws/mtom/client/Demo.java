package ws.mtom.client;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Demonstration on how to use WS MTOM
 * 
 * @author gash1
 * 
 */
public class Demo extends BlogClient {
	Properties prop;

	public Demo() {
		setAuthor("Cadence");
		prop = new Properties();

		final InputStream in1 = Thread.currentThread().getContextClassLoader()
				.getResourceAsStream("test.properties");
		if (in1 == null) {
			System.out.println("properties are null");
		}

		if (in1 != null) {
			try {
				prop.load(in1);
			} catch (final IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
	}

	public void demoDownload(final String mediaType, final String searchType,
			final String value) throws Exception {
		System.out.println("\nDemo: Download Blog for searchType: "
				+ searchType + "and Value: " + value);
		File[] f = null;
		final File destintion = new File(
				prop.getProperty("clientFileStore"));
		
			f = retrieveBlog(mediaType, searchType, value, destintion);

		if (f != null) {
			System.out.println("Retrieved Blogs paths: ");
			for (int i = 0; i < f.length; i++) {
				System.out.println(f[i].getAbsolutePath());
			}
		} else {
			System.out.println("Failed to retrieve Blog");
		}
	}

	/**
	 * the demonstration
	 * 
	 * @param args
	 */
	public static void main(final String[] args) {
		try {
			final Demo d = new Demo();
			// DownloadBlogrequest - searchtype and value
			final String mediaType = "Blog";
			final String searchtype = "Tag";
			final String value = "health";
			d.demoDownload(mediaType, searchtype, value);

			// demonstrate exception handling - these two calls will fail

			// ID does not exist
			try {
				// d.demoDownload("fakeID");
			} catch (final Exception e) {
				System.out
						.println("Successfully failed to download a file with a fake ID.");
				// e.printStackTrace();
			}

			// not the owner of the file (pop must be ran first) and the ID must
			// match a file I don't own. NOTE: a test case should be created to
			// allow the setup where a well-known ID is not owned by the
			// caller/developer.
			try {
				// d.demoDownload("3");
			} catch (final Exception e) {
				System.out
						.println("Successfully failed to download a file that I do not own.");
				// e.printStackTrace();
			}

		} catch (final Exception e) {
			e.printStackTrace();
		}
	}
}
